This projec contains small programs and demos related with different XML technologies.

dtd-xml-project: Create an DTD schema with xml language. It's a meta-modelling task in which all the constraints of DTD are represented in XML syntax.

psvi-project: Create schemas for one simple XML Document with XML Schema and DTD in order to modify the PSVI (Post-Schema Validation Infoset).

xlst-dtdx-project: Transform an XML with XSLT rules and templates. Simple task of transformation.

xquery-calc-project: Use XQuery functions in order to evaluate one simple XML document and show the result of the operation.

xquery-deceptive-project: XQuery functions to process and identify some strange cases in XML documents related with Namespaces treatment.

xquery-validation-project: XQuery and XPath functions to validate one simple XML document.

xquery-wxs-project: XQuery functions to evaluate different type of queries based on the validation process and the PSVI details.

xsd-project: A simple exercise to create and validate an XML document against an XSD document.