# You can run this with "python3 PyRelaxNgValidator.py <path_to_xml_file> <path_to_RelaxNG_file>"
# It only works on RelaxNG schemas in XML syntax, so you may have to translate yours first
#

from lxml import etree
from io import StringIO
import sys

filename_xml = sys.argv[1]
filename_rng = sys.argv[2]

# open and read schema file
with open(filename_rng, 'r') as schema_file:
    schema_to_check = schema_file.read()

# open and read xml file
with open(filename_xml, 'r') as xml_file:
    xml_to_check = xml_file.read()


# ...fill in something to return the answer for the quiz question,
# i.e. a human readable version of the arithmetic expression in the XML file (as a string, no other strings around it)
# here we now assume that your input XML is both well-formed and valid wrt calc1! 
# print(...)
