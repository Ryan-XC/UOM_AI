# Q2 is a script that returns, for each student, his or her ID and
# the percentage (of all available points) they have scored. 
#   
# You should create and write your results into a .csv file q2Out.csv
# with 2 columns and the header row studentID and PercentageMark.
#

import csv
with open("exam_for_2019.csv") as csvfile:
