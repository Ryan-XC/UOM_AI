# Q4 is a script that returns, for each question, the question ID and the number# students  who have passed this question (assuming that a student passes a 
#   question if they score at least half the points possible). 
#   
# You should create and write your results into a .csv file q4Out.csv
# with 2 columns and the header row questionID, StudentsPassed. 
#

import csv
with open("exam_for_2019.csv") as csvfile:
