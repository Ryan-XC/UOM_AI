# Q3 is a script that returns, for each student, his or her ID, the number of points 
#   scored on the autograded questions, the number of points scored on the manually graded 
#   questions, and total number of points scored. 
#   
# You should create and write your results into a .csv file q3Out.csv
# with 4 columns and the header row  studentID, RawAutogradedMark, RawManualMark, RawTotalMark.
#

import csv
with open("exam_for_2019.csv") as csvfile:
