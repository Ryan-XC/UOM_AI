import sys
from jsonschema import validate

def validate_address(address_file_path):
    """This function validates the input JSON ﬁle against your 
       schema and returns 
            "yes" 
       if your addresses contain a large household (as per M1), 
            "no" 
       otherwise, and that uses the JSON Schema validator 
       documented at 
           https://python-jsonschema.readthedocs.io/en/stable/validate/ 
       to validate the input against your schema. In case this validation 
       fails, your program should return 
            "invalid". 

       You can use "pip install jsonschema" to install jsonschema."""
    pass

if __name__=='__main__':
    address_file_path = sys.argv[1]
    print(validate_address(address_file_path))
