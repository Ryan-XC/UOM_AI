Load the given database m1.db into DB_Browser. Have a look around. 

Create/add the tables you need for your schema in the same database (i.e., don’t create a new database). 

Write the 
- queries you need to populate your tables from Import (into 1 query, possibly with various "SELECT…” statements)
- queries for q1.sql and q2.sql 
and safe these using the “Save SQL file” icon in the “Execute SQL” tab using the names given (Populate.sql, q1.sql, q2.sql) 

Test your answers! 

Finally, export your database via the “Export Database to SQL file” command from the “File” menu.  

Check file names, copy and create the directory, check names again, zip, and submit.  
