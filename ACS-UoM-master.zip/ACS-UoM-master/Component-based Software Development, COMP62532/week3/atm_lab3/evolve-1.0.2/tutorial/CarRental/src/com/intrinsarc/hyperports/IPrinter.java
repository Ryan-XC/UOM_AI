package com.intrinsarc.hyperports;

public interface IPrinter
{
	public void print(String warning);
}
