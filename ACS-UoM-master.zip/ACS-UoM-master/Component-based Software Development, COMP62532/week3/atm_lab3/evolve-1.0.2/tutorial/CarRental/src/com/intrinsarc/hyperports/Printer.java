package com.intrinsarc.hyperports;


public class Printer
// start generated code
	// main port
 implements com.intrinsarc.hyperports.IPrinter
{
// end generated code

	public void print(String msg)
	{
		System.out.println("Printer: " + msg);
	}
}
