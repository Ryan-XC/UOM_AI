package com.intrinsarc.base;

import java.util.*;

public interface IRentalCarDetails
// start generated code
{
// end generated code
	String getModel();
	Date getPurchased();
	void setRenterName(String renterName);
	String getRenterName();
	boolean isRented();
}