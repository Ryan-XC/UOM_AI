package uk.man.atm;

public interface IRun
// start generated code
{
// end generated code
	//@todo add in the methods
}
