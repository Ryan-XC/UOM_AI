
Running Evolve
--------------

To run Evolve, either run evolve.exe, or double-click on evolve.jar in a file manager, or execute it using java:

  java -jar evolve.jar

You must have at Java 1.6 or above.

If you have any doubts about the version, type:

  java -version

If you have any problems, feel free to send mail to info@intrinsarc.com and I will help you resolve any issues.

-----------------------
Andrew McVeigh, London

