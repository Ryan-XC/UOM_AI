package uk.man.atm;

import com.intrinsarc.backbone.runtime.api.*;

public class ATMRunner
// start generated code
	// main port
 implements IRun
{
	// required ports
	private uk.man.atm.IAtmCli show;

	// port setters and getters
	public void setShow(uk.man.atm.IAtmCli show) { this.show = show; }

// end generated code
	public boolean run(String[] arg0) {
		// TODO Auto-generated method stub
	    System.out.println("START");
		return false;
	}




}
