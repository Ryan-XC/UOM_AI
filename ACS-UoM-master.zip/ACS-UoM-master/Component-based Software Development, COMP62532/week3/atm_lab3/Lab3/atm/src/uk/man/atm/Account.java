package uk.man.atm;

import com.intrinsarc.backbone.runtime.api.*;

public class Account
// start generated code
	// main port
 implements uk.man.atm.IAccount
{
	// attributes
	private int balance;
	private int number;

	// attribute setters and getters
	public int getBalance() { return balance; }
	public void setBalance(int balance) { this.balance = balance;}
	public int getNumber() { return number; }
	public void setNumber(int number) { this.number = number;}

// end generated code


}
