package uk.man.atm;

public interface IAccount
// start generated code
{
// end generated code
	//@todo add in the methods
}
