package uk.man.atm;

public interface IAtmCli
// start generated code
{
// end generated code
	//@todo add in the methods
	
	public void show();	

}
