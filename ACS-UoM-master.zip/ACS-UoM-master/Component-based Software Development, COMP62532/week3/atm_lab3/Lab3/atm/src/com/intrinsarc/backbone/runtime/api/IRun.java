package com.intrinsarc.backbone.runtime.api;

public interface IRun
// start generated code
{
// end generated code
	//@todo add in the methods
}
