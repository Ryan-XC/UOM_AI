package uk.man.atm;

public interface ICardReader
// start generated code
{
// end generated code
	//@todo add in the methods
	public int readAccountNo();

}
