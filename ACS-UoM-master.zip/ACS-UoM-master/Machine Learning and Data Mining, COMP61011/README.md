### COMP61011: Machine Learning and Data Mining
---------------------------------------

Machine Learning and Data Mining at _The University of Manchester_ 2015.
